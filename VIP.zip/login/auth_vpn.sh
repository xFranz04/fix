#!/bin/bash
url="api.bidek.host"
if wget --spider https://$url 2>/dev/null; then
	site="https://$url"
else
	site="http://$url"
fi

username=`head -n1 $1 | tail -1`   
password=`head -n2 $1 | tail -1`
server_ip="xxx.xxx.xxx.xxx"
submitted="vip"
post="submitted=$submitted&username=$username&password=$password&server_ip=$server_ip"
auth_vpn="$(wget -qO- --post-data="$post" "$site/api/auth_vpn.php")"
echo $auth_vpn > /root/auth.txt
login="$(cat "/root/auth.txt")"
[ $login != '' ] && [ $login == 1 ] && echo "user : $username" && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1
