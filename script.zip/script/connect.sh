#!/bin/bash
url="api.bidek.host"
if wget --spider https://$url 2>/dev/null; then
	site="https://$url"
else
	site="http://$url"
fi

submitted="client-connect"
category="xxxxx"

server_ip="xxx.xxx.xxx.xxx"
server_port="$trusted_port"
timestamp="$(date +'%FT%TZ')"
ipaddress="$trusted_ip:$trusted_port"
since_connected="$time_ascii"

cpost="submitted=$submitted&username=$common_name&category=$category&bytes_received=$bytes_received&bytes_sent=$bytes_sent&server_ip=$server_ip&ipaddress=$ipaddress"
connection_logs="$(wget -qO- --post-data="$cpost" "$site/api/connection_logs.php")"
